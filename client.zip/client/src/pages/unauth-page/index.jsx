


function UnauthPage() {
    return ( 
        <h1> Access Denied! </h1>
     );
}

export default UnauthPage;