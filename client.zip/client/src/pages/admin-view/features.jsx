function AdminFeatures() {
    return ( 
        <div>Admin Features</div>
     );
}

export default AdminFeatures;