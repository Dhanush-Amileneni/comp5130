function AdminProducts() {
    return ( 
        <div>Admin Products</div>
     );
}

export default AdminProducts;