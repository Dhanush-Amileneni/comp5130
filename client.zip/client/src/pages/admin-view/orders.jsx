function AdminOrders() {
    return ( 
        <div>Admin Orders</div>
     );
}

export default AdminOrders;