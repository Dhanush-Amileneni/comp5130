function AdminDashboard() {
    return ( 
        <div>Admin Dashboard</div>
     );
}

export default AdminDashboard;