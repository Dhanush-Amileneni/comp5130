


function ShoppingAccount() {
    return ( 
        <div> shopping account </div>
     );
}

export default ShoppingAccount;