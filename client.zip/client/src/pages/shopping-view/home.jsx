


function ShoppingHome() {
    return ( 
        <div> shopping home </div>
     );
}

export default ShoppingHome;