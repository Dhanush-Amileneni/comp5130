





function ShoppingList() {
    return ( 
        <div> shopping list </div>
     );
}

export default ShoppingList;