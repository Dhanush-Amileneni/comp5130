


function ShoppingCheckout() {
    return ( 
        <div> shopping checkout </div>
     );
}

export default ShoppingCheckout;