


function NotFound() {
    return ( 
        <div> page not found </div>
     );
}

export default NotFound;