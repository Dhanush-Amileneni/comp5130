


function ShoppingHeader() {
    return ( 
        <div> shopping view header </div>
     );
}

export default ShoppingHeader;