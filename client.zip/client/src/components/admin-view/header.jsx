function AdminHeader() {
  return ( 
    <div>admin header</div>
   );
}

export default AdminHeader;